# Module 1: Web Authentication, Server & Database

## Bước 0: Cài đặt
```bash
cd server
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Bước 1: Database (SQLite)
File `app/db.py` tạo 5 bảng: `users`, `compartments`, `orders`, `used_tokens` (chống replay), `audit_log`.
```bash
python seed.py        # tạo navbot.db + user mẫu
```
| ID | Mật khẩu | Vai trò |
|---|---|---|
| admin01 | admin123 | admin |
| staff01 | staff123 | staff |
| SV001 / SV002 | pass001 / pass002 | recipient |

## Bước 2: Bảo mật (`app/security.py`)
- Hash mật khẩu bằng `bcrypt` (dùng thẳng thư viện, tránh lỗi tương thích của passlib).
- Có 2 loại JWT, không được gộp chung:
  - **QR token** (`typ=qr`): sống 60 s, dùng một lần, gắn với `DELIVERY_POINT`. Robot lấy qua `GET /api/qr/token` với header `X-Robot-Key`.
  - **Session token** (`typ=session`): cấp sau khi login. Recipient chỉ sống 120 s và mang theo `jti` của QR đã dùng để đăng nhập.

## Bước 3: API (`app/main.py`)
| Endpoint | Ai gọi | Việc làm |
|---|---|---|
| `POST /api/orders/create` | admin | Tìm khoang EMPTY, đặt RESERVED, tạo order, báo mission manager qua WebSocket |
| `POST /api/orders/{id}/loaded` | staff/admin | Order thành LOADED, khoang thành LOADED (UC03 rút gọn) |
| `GET /api/qr/token` | robot | Cấp QR token mới |
| `POST /api/auth/login` | mọi người | Kiểm tra mật khẩu, lockout; recipient phải kèm QR token hợp lệ |
| `POST /api/unlock` | recipient | Tìm order LOADED của đúng user, tiêu thụ `jti` (anti-replay), mở khoang, gửi `{"cmd":"UNLOCK"}` |
| `GET /api/orders`, `GET /api/audit` | staff/admin | Giám sát (UC06) |
| `WS /ws/robot?key=...` | node ROS 2 bridge | Nhận lệnh UNLOCK / ORDER_CREATED |

Luồng chống replay: QR token chỉ được ghi vào `used_tokens` khi unlock thành công. Dùng lại lần hai sẽ bị từ chối ở login (401).

## Bước 4: Chạy server
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```
- Tài liệu API tự động: http://localhost:8000/docs
- Trang dispatch: http://localhost:8000/dispatch.html
- Trang login của recipient: http://localhost:8000/login.html?t=<qr_token>

## Bước 5: Test thủ công bằng curl
```bash
# 1. admin đăng nhập
curl -s localhost:8000/api/auth/login -H 'Content-Type: application/json' \
  -d '{"user_id":"admin01","password":"admin123"}'
# 2. tạo order (thay <ADMIN_TOKEN>)
curl -s localhost:8000/api/orders/create -H 'Content-Type: application/json' \
  -H 'Authorization: Bearer <ADMIN_TOKEN>' -d '{"recipient_id":"SV001","details":"com ga"}'
# 3. đánh dấu đã nạp hàng (đăng nhập staff01 rồi gọi)
curl -s -X POST localhost:8000/api/orders/1/loaded -H 'Authorization: Bearer <STAFF_TOKEN>'
# 4. giả lập robot lấy QR token
curl -s localhost:8000/api/qr/token -H 'X-Robot-Key: dev-robot-key'
# 5. mở http://localhost:8000/login.html?t=<TOKEN> trên điện thoại hoặc trình duyệt, đăng nhập SV001
```
Quên bước nào thì xem bảng `audit_log` (`GET /api/audit`).

## Bước 6: Chạy unit test
```bash
pytest -q
```
7 test: luồng đúng, QR dùng lại, sai user, QR hết hạn, thiếu QR, khóa tài khoản, phân quyền.

## Bước 7: HTTPS tự ký (demo)
```bash
openssl req -x509 -newkey rsa:2048 -nodes -keyout key.pem -out cert.pem -days 30 -subj "/CN=navbot.local"
uvicorn app.main:app --host 0.0.0.0 --port 8443 --ssl-keyfile key.pem --ssl-certfile cert.pem
```

## Biến môi trường (đặt khi chạy thật)
`JWT_SECRET`, `ROBOT_KEY`, `DELIVERY_POINT` (mặc định DP1), `DB_PATH`, `REQUIRE_ROBOT=1` (trả 503 nếu robot chưa kết nối, giữ khoang khóa theo UC04).

## Bàn giao cho Module 2 (ROS 2)
- Node QR gọi `GET /api/qr/token` mỗi 50 s, rồi vẽ QR cho URL `https://<ip>:8443/login.html?t=<token>`.
- Node bridge kết nối `wss://<ip>:8443/ws/robot?key=<ROBOT_KEY>` và nhận JSON:
  - `{"cmd":"UNLOCK","compartment":1,"order_id":3}` chuyển thành frame UART UNLOCK
  - `{"event":"ORDER_CREATED",...}` chuyển cho mission manager

## Việc còn thiếu (làm tiếp)
- Endpoint hoàn tất đơn (khoang về EMPTY sau khi đóng cửa, cần tín hiệu LOCK_STATUS từ ECE).
- Staff phải quét QR trước khi mở khoang nạp hàng (UC03 đầy đủ).
- Tự động đóng đơn quá hạn, xử lý đơn bị hủy.
